﻿Taskobo Diagrams — 日本語の図表サンプル

煩雑な資料整理をAIに任せ、PMは判断、対話、成果の実現に集中する。

1. index.htmlを開き、4種類の全体図を確認する。閲覧に開発環境は不要だ。
2. プロジェクトの事実、編集用ソース、AI-TASK.txtを普段のAIに渡す。
3. 不足情報、仮定、責任者、日付、受入条件を確認する。
4. スタイルツールで修正後のソースを描画し、ツール内のDOCSKOBOリンクから編集と出力を続ける。

スタイルツール（現在は日本語画面）：https://taskobo.com/free-tools/mermaid/
文書ワークスペース：https://docskobo.com/app
プロジェクト：https://github.com/dfzzq719/taskobo-diagrams
Taskobo：https://taskobo.com/

4種類とも同じ架空の顧客サービスシステム導入事例を扱う。集計基準日は2026-10-14だ。
全体のPNG、SVG、編集用ソースを含み、AIサービスやキーは含まない。
図表のサンプルパックであり、現在の中国語Alpha Skillと2回の会議を扱う教材とは別のものだ。
