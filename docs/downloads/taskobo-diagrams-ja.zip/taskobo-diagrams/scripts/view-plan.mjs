import {validateProject} from './project.mjs';
import {projectViews} from './view-model.mjs';

const short=(value,length)=>{const chars=Array.from(String(value));return chars.length>length?chars.slice(0,length-1).join('')+'…':String(value);};
const label=value=>chunks(Array.from(String(value).replace(/[\r\n\t]/g,' ')),24).map(chars=>chars.join('').replace(/[&<>"'\[\]{}:;`%#\\]/g,c=>'#'+c.codePointAt(0)+';')).join('<br/>');
const chunks=(items,size)=>Array.from({length:Math.ceil(items.length/size)},(_,i)=>items.slice(i*size,(i+1)*size));
const day=value=>/^\d{4}-\d{2}-\d{2}$/.test(value)&&Number.isFinite(Date.parse(value+'T00:00:00Z'))&&new Date(value+'T00:00:00Z').toISOString().slice(0,10)===value;

/** Pages are views of the complete validated project, never new project states. */
export function planViews(project,{pageSize=12,group,from,to}={}){
  validateProject(project);
  pageSize=Number(pageSize);
  if(!Number.isInteger(pageSize)||pageSize<1||pageSize>20)throw new Error('--page-size の形式： 1–20 の整数。');
  if(group&&!project.groups.some(item=>item.id===group))throw new Error('グループが見つからない：'+group);
  for(const [key,value]of Object.entries({from,to}))if(value&&!day(value))throw new Error('--'+key+' に必要な形式： YYYY-MM-DD の有効な日付。');
  if(from&&to&&from>to)throw new Error('--from は次の日付より遅くできない： --to。');
  const tasks=project.tasks.filter(task=>!task.archived&&(!group||task.groupId===group)&&
    (!from||[task.baseline.finish,task.forecast.finish,task.actualFinish||''].some(date=>date>=from))&&
    (!to||[task.baseline.start,task.forecast.start].some(date=>date<=to)));
  if(!tasks.length)throw new Error('絞込み後に有効な作業パッケージがない。グループ、期間、アーカイブ状態を確認する。');
  const jobs=[],counts={};
  const add=(kind,source,title,pageTasks,extra={})=>{
    const number=counts[kind]=(counts[kind]||0)+1,id=kind+(number===1?'':'-'+String(number).padStart(2,'0'));
    jobs.push({id,kind,source,title,taskIds:pageTasks.map(task=>task.id),...extra});
  };
  const compact=task=>({...task,title:short(task.title,64),acceptance:short(task.acceptance,100)});
  for(const item of project.groups){
    const pages=chunks(tasks.filter(task=>task.groupId===item.id),pageSize);
    pages.forEach((page,index)=>{
      const title=item.name+'｜'+(index+1)+' / '+pages.length;
      const copy={...project,name:short(project.name,24)+'｜'+short(title,20),groups:[item],roles:project.roles.map(role=>({...role,name:short(role.name,32)})),tasks:page.map(compact)};
      const views=projectViews(copy,{validate:false,vertical:true});
      for(const [part,work]of chunks(page,4).entries()){
        const wbs=projectViews({...copy,tasks:work.map(compact)},{validate:false,vertical:true}).wbs;
        add('wbs',wbs,'作業分解｜'+title+(page.length>4?'｜部分 '+(part+1):''),work,{groupId:item.id});
      }
      for(let roleStart=0;roleStart<project.roles.length;roleStart+=8){
        add('raci',views.raci,'責任分担｜'+title+'｜役割 '+(roleStart+1)+'–'+Math.min(roleStart+8,project.roles.length),page,
          {roleIds:project.roles.slice(roleStart,roleStart+8).map(role=>role.id),...(project.roles.length>8?{rolePanel:{from:roleStart,count:Math.min(8,project.roles.length-roleStart)}}:{})});
      }
      add('schedule',views.schedule,'工程表｜'+title,page,{groupId:item.id});
    });
  }
  const byId=new Map(project.tasks.map(task=>[task.id,task]));
  const edges=tasks.flatMap(task=>task.dependsOn.map(id=>({from:id,to:task.id})));
  chunks(edges,Math.min(pageSize,16)).forEach((page,index)=>{
    const ids=[...new Set(page.flatMap(edge=>[edge.from,edge.to]))],selected=new Set(tasks.map(task=>task.id));
    const degree=new Map();for(const edge of page)for(const key of ['from','to'])degree.set(key+edge[key],(degree.get(key+edge[key])||0)+1);
    const source=['flowchart '+(Math.max(...degree.values())>2?'LR':'TB'),'  %% 矢印は先行作業から後続作業へ向かう。ページをまたぐタスクも同じ識別子で表示する：ID は変えない。',
      ...ids.map((id,i)=>`  N${i}["${label(id+' '+short(byId.get(id).title,64))}${!selected.has(id)?'<br/>別グループ／選択範囲外の先行作業':''}${byId.get(id).archived?'<br/>アーカイブ済み':''}"]`),
      ...page.map(edge=>`  N${ids.indexOf(edge.from)} --> N${ids.indexOf(edge.to)}`)].join('\n')+'\n';
    add('dependencies',source,'依存関係｜'+(index+1),ids.map(id=>byId.get(id)),{edges:page});
  });
  return {jobs,selection:{taskIds:tasks.map(task=>task.id),pageSize,group:group||null,from:from||null,to:to||null},
    notes:['図内の名称と受入条件は短く表示する。全文は作業パッケージ明細とプロジェクトスナップショットを参照する。','期間の絞込みは重なる作業を選択するだけで、基準、予測、依存関係は変更しない。']};
}
