#!/usr/bin/env node
import { readFile, mkdir, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
import { validateProject, prepareUpdate, applyUpdate, reviewUpdate } from './project.mjs';
import { initialize } from './init.mjs';

const HELP = `Taskobo Diagrams プロジェクト資料の更新（Node.js 22.12+）

init   [--from 計画.mdまたは.csv] --out 新しい草稿ディレクトリ [--name プロジェクト名] [--as-of YYYY-MM-DD]
check  --project プロジェクト.json
review --project プロジェクト.json --update 今週/更新.json --out 新しいレビューディレクトリ
accept --project プロジェクト.json --update 今週/更新.json --select 変更1,変更2 --out 新しいプロジェクト.json

review 生成 candidate.json、review.json、review.md；プレビューは承認を意味しない。
accept 適用対象： --select で明示的に選択した変更のみ。入力を変更せず、既存の出力を上書きしない。
出典ファイルは更新ファイルと同じディレクトリツリー内に置く。引用の一致は提案の正しさや承認を証明しない。
通常の更新では承認済み基準を変更できない baseline，承認済み基準の改訂は別途扱う。
`;

async function jsonFile(file) {
  let source;
  try { source = await readFile(file, 'utf8'); } catch (error) { throw new Error(`ファイルを読み込めない ${file}：${error.code ?? error.message}`); }
  try { return JSON.parse(source.replace(/^\uFEFF/u, '')); } catch { throw new Error(`JSON 形式が無効：${file}`); }
}

function options(args) {
  const result = {};
  for (let index = 0; index < args.length; index += 2) {
    const key = args[index];
    const value = args[index + 1];
    if (!['--project', '--update', '--out', '--select', '--from', '--name', '--as-of'].includes(key) || !value || value.startsWith('--') || Object.hasOwn(result, key.slice(2))) throw new Error(`引数が無効または重複：${key}。実行： --help で使い方を確認する`);
    result[key.slice(2)] = value;
  }
  return result;
}

function requireOptions(values, required, allowed) {
  for (const key of required) if (!values[key]) throw new Error(`不足： --${key} 引数`);
  for (const key of Object.keys(values)) if (!allowed.includes(key)) throw new Error(`このコマンドでは使用できない： --${key}`);
}

const pretty = (value) => `${JSON.stringify(value, null, 2)}\n`;
const md = (value) => String(value).replace(/[\\`*_{}\[\]<>|]/gu, '\\$&').replace(/\r?\n/gu, ' ');

function reviewMarkdown(review) {
  const lines = [
    `# ${md(review.projectName)}：プロジェクト更新レビュー`, '',
    '**更新案のプレビュー・未確認。** 候補には未適用の全提案を反映する。PMが項目ごとに選択するためのプレビューであり、承認を意味しない。', '',
    `更新：${md(review.updateId)}；集計基準日：${review.asOf}。`, '',
    'スクリプトは形式、出典引用、旧値の競合を検証する。引用の存在は提案の正しさ、完全性、権限を証明しない。', '',
  ];
  for (const change of review.changes) {
    lines.push(`## ${md(change.id)}${change.alreadyApplied ? '（適用済み・再実行しても再変更しない）' : '（確認待ち）'}`, '');
    lines.push(`操作：${md(change.kind)}${change.targetId ? `；対象：${md(change.targetId)}.${md(change.field)}` : ''}。`, '');
    if (Object.hasOwn(change, 'expected')) lines.push('変更前：', '```json', pretty(change.expected).trimEnd(), '```', '');
    lines.push('提案値：', '```json', pretty(change.value).trimEnd(), '```', '');
    for (const evidence of change.evidence) lines.push(`根拠（${md(evidence.sourceId)}）：${md(evidence.quote)}`, '');
  }
  lines.push('## 出典スナップショット', '', '| 出典 ID | ファイル | SHA-256 |', '| --- | --- | --- |');
  for (const source of review.sources) lines.push(`| ${md(source.id)} | ${md(source.file)} | ${source.sha256} |`);
  lines.push('', '変更の選択には更新ファイル内の安定したIDを使用する。例：', '', '```sh', 'node scripts/pm.mjs accept --project プロジェクト.json --update 今週/更新.json --select 変更1,変更2 --out プロジェクト-新しい版.json', '```', '');
  return lines.join('\n');
}

export async function main(args = process.argv.slice(2)) {
  if (!args.length || args.includes('--help') || args.includes('-h')) { process.stdout.write(HELP); return; }
  const [command, ...rest] = args;
  if (!['init', 'check', 'review', 'accept'].includes(command)) throw new Error(`不明なコマンド：${command}。実行： --help で使い方を確認する`);
  const opts = options(rest);
  if(command==='init'){requireOptions(opts,['out'],['from','out','name','as-of']);console.log(JSON.stringify(await initialize(opts),null,2));return;}
  const required = command === 'check' ? ['project'] : command === 'review' ? ['project', 'update', 'out'] : ['project', 'update', 'select', 'out'];
  requireOptions(opts, required, required);
  const project = validateProject(await jsonFile(opts.project));
  if (command === 'check') {
    process.stdout.write(`プロジェクトの検証に成功：${project.name}（${project.tasks.length} タスク、集計基準日 ${project.statusDate}）\n`);
    return;
  }
  const update = await jsonFile(opts.update);
  const prepared = await prepareUpdate(project, update, { updatePath: opts.update });
  if (command === 'review') {
    const review = reviewUpdate(project, prepared);
    try { await mkdir(opts.out); } catch (error) {
      if (error.code === 'EEXIST') throw new Error(`レビュー出力先が既に存在する。上書きできない：${opts.out}`);
      throw new Error(`レビューディレクトリを作成できない ${opts.out}：${error.code ?? error.message}`);
    }
    await writeFile(path.join(opts.out, 'candidate.json'), pretty(review.candidateProject), { flag: 'wx' });
    await writeFile(path.join(opts.out, 'review.json'), pretty(review), { flag: 'wx' });
    await writeFile(path.join(opts.out, 'review.md'), reviewMarkdown(review), { flag: 'wx' });
    process.stdout.write(`更新案レビューを生成した：${opts.out}（${review.pendingChangeIds.length} 項目が確認待ち）\n`);
    return;
  }
  const selectedIds = opts.select.split(',').map((value) => value.trim());
  if (selectedIds.some((value) => !value)) throw new Error('--select 空でない変更識別子が必要： ID，カンマで区切る');
  const candidate = applyUpdate(project, prepared, selectedIds);
  try { await writeFile(opts.out, pretty(candidate), { flag: 'wx' }); } catch (error) {
    if (error.code === 'EEXIST') throw new Error(`プロジェクト出力ファイルが既に存在する。上書きできない：${opts.out}`);
    throw new Error(`プロジェクトの出力を書き込めない ${opts.out}：${error.code ?? error.message}`);
  }
  process.stdout.write(`明示された選択に基づき新しい状態を生成した：${opts.out}（元のプロジェクトは変更していない）\n`);
}

if (process.argv[1] && pathToFileURL(path.resolve(process.argv[1])).href === import.meta.url) {
  main().catch((error) => {
    process.stderr.write(`エラー：${error.message}\n`);
    process.exitCode = 1;
  });
}
