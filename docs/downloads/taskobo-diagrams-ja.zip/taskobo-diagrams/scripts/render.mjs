#!/usr/bin/env node
import {createServer} from 'node:http';
import {readFile,mkdtemp,rm,stat} from 'node:fs/promises';
import {randomBytes} from 'node:crypto';
import {spawn} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
import os from 'node:os';
import {validateProject} from './project.mjs';
import {projectSummary,reviewPage} from './view-model.mjs';
import {planViews} from './view-plan.mjs';
import {sha,verifyOutput,beginOutput} from './output.mjs';

const ROOT=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const textBytes=bytes=>Buffer.from(bytes.toString('utf8').replace(/\r\n/g,'\n'));
const delay=ms=>new Promise(resolve=>setTimeout(resolve,ms));
const usage=`Taskobo Diagrams 日本語プロジェクト更新パッケージ
Node.js 22.12+；図形の描画に必要な導入済みブラウザー： Chrome/Edge，ブラウザーのダウンロードは行わない。

node scripts/render.mjs --doctor [--browser <パス>]
node scripts/render.mjs --verify [--out <既存の更新パッケージ>]
node scripts/render.mjs --project <プロジェクト.json> --out <ディレクトリ> [--review <レビュー.json>]
  [--force] [--format all|svg|sources] [--page-size 1..20]
  [--group <グループID>] [--from YYYY-MM-DD] [--to YYYY-MM-DD]
  [--browser <パス>] [--timeout <図ごとのミリ秒、1000..300000>]

既定の1グループ・1ページ当たりの作業数： 12 項目。責任分担表の1ページ当たりの役割数上限： 8 役割。責任分担は全役割を合わせて検証する。
--force 本ツールで生成し、手修正や追加ファイルがないディレクトリだけを更新する。失敗時は既存の結果を置換しない。
--format sources ソースとレビューページだけを出力する。ブラウザーは不要で、図形の描画は未検証だ。
終了コード：0 全処理成功、2 一部失敗（ソース、有効な SVG と診断を保持）、1 入力または環境のエラー。
`;
function argumentsFor(argv){
  const args={};
  for(let i=0;i<argv.length;i++){
    const key=argv[i],name=key.slice(2);
    if(Object.hasOwn(args,name))throw new Error('引数が重複：'+key);
    if(['--verify','--doctor','--help','--force'].includes(key)){args[name]=true;continue;}
    if(!['--project','--review','--out','--browser','--format','--page-size','--group','--from','--to','--timeout'].includes(key)||!argv[i+1]||argv[i+1].startsWith('--'))throw new Error('不明または値のない引数：'+key+'；実行： --help で使い方を確認する。');
    args[name]=argv[++i];
  }
  if(args.format&&!['all','svg','sources'].includes(args.format))throw new Error('--format の形式： all、svg または sources。');
  args.timeout=Number(args.timeout||180000);
  if(!Number.isInteger(args.timeout)||args.timeout<1000||args.timeout>300000)throw new Error('--timeout の形式： 1000–300000 ミリ秒。');
  return args;
}
function requireNode(){
  const [major,minor]=process.versions.node.split('.').map(Number);
  if(major<22||(major===22&&minor<12)||typeof WebSocket!=='function')throw new Error('必要： Node.js 22.12 以降。ネイティブ機能： WebSocket；導入済みの互換版を使用する： Node.js。');
}

async function verifyRuntime(){
  const runtime=path.join(ROOT,'assets/runtime'),bytes=textBytes(await readFile(path.join(runtime,'manifest.json'))),manifest=JSON.parse(bytes);
  if(manifest.schema!=='kobo.pm-runtime/v1'||manifest.coreVersion!=='0.1.3'||manifest.mermaidVersion!=='12.2.0')throw new Error('同梱の図表 runtime の版に互換性がない。パッケージ全体を再導入する： Skill。');
  const required=['core/index.mjs','core/version.mjs','core/profile.mjs','core/document-renderer.mjs','core/diagram-renderer.mjs','mermaid.min.js','LICENSE','NOTICE','mermaid-LICENSE.txt'];
  if(required.some(name=>!manifest.fileSHA256?.[name]))throw new Error('runtime manifest に必要なファイルがない。');
  for(const [name,expected]of Object.entries(manifest.fileSHA256)){
    const file=path.resolve(runtime,name);
    if(!file.startsWith(runtime+path.sep)||!/^[a-f0-9]{64}$/.test(expected))throw new Error('runtime manifest に無効なパスまたはハッシュが含まれる。');
    if(sha(textBytes(await readFile(file)))!==expected)throw new Error('runtime 整合性の検証に失敗：'+name+'。パッケージ全体を再導入する： Skill。');
  }
  return {manifest,manifestSHA256:sha(bytes)};
}

async function findBrowser(explicit){
  const candidates=explicit?[path.resolve(explicit)]:[
    process.env.KOBO_CHROME_PATH,process.env.CHROME_BIN,process.env.TASKOBO_CHROME_PATH,
    path.join(process.env.PROGRAMFILES||'C:/Program Files','Google/Chrome/Application/chrome.exe'),
    path.join(process.env['PROGRAMFILES(X86)']||'C:/Program Files (x86)','Microsoft/Edge/Application/msedge.exe'),
    path.join(process.env.PROGRAMFILES||'C:/Program Files','Microsoft/Edge/Application/msedge.exe'),
    process.env.LOCALAPPDATA&&path.join(process.env.LOCALAPPDATA,'Google/Chrome/Application/chrome.exe'),
    '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome','/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge',
    '/usr/bin/google-chrome','/usr/bin/google-chrome-stable','/usr/bin/chromium','/usr/bin/chromium-browser','/usr/bin/microsoft-edge'
  ].filter(Boolean);
  for(const file of candidates){try{if((await stat(file)).isFile())return file;}catch{}}
  throw new Error('本機に見つからない： Chrome/Edge。指定オプション： --browser で導入済みブラウザーの絶対パスを指定する。スクリプトはダウンロードや導入を行わない。');
}


export async function connectCDP(url){
  const socket=new WebSocket(url),pending=new Map(),listeners=new Set(),waits=new Set();let serial=0;
  const disconnected=()=>Object.assign(new Error('ブラウザーとの接続が切れた。次の診断を確認する： diagnostics.json 終了状態とログを確認するか、次の値を小さくする： --page-size 再試行する。'),{code:'BROWSER_DISCONNECTED'});
  await new Promise((resolve,reject)=>{
    const timer=setTimeout(()=>{socket.close();reject(Object.assign(new Error('ブラウザーのデバッグポートへの接続がタイムアウトした。'),{code:'BROWSER_CONNECT_TIMEOUT'}));},10000);
    socket.addEventListener('open',()=>{clearTimeout(timer);resolve();},{once:true});
    socket.addEventListener('error',()=>{clearTimeout(timer);reject(disconnected());},{once:true});
  });
  const fail=()=>{for(const item of pending.values()){clearTimeout(item.timer);item.reject(disconnected());}pending.clear();for(const item of [...waits])item.fail(disconnected());};
  socket.addEventListener('close',fail);socket.addEventListener('error',fail);
  socket.addEventListener('message',event=>{
    let message;try{message=JSON.parse(String(event.data));}catch{return;}
    if(message.id){const item=pending.get(message.id);if(!item)return;pending.delete(message.id);clearTimeout(item.timer);message.error?item.reject(new Error(message.error.message)):item.resolve(message.result);}
    else for(const listener of [...listeners])listener(message);
  });
  return {
    get open(){return socket.readyState===WebSocket.OPEN;},
    on(listener){listeners.add(listener);},
    send(method,params={},sessionId,timeout=180000){
      if(socket.readyState!==WebSocket.OPEN)return Promise.reject(disconnected());
      return new Promise((resolve,reject)=>{const id=++serial;const timer=setTimeout(()=>{pending.delete(id);reject(Object.assign(new Error('ブラウザー処理がタイムアウトした：'+method+'；次の値を小さくする： --page-size または指定する： --format svg 再試行する。'),{code:'BROWSER_CALL_TIMEOUT'}));},timeout);pending.set(id,{resolve,reject,timer});try{socket.send(JSON.stringify({id,method,params,...(sessionId?{sessionId}:{})}));}catch(error){clearTimeout(timer);pending.delete(id);reject(error);}});
    },
    wait(method,sessionId){if(socket.readyState!==WebSocket.OPEN)return Promise.reject(disconnected());return new Promise((resolve,reject)=>{
      const item={fail(error){clearTimeout(timer);listeners.delete(listener);waits.delete(item);reject(error);}};
      const listener=message=>{if(message.method===method&&message.sessionId===sessionId){clearTimeout(timer);listeners.delete(listener);waits.delete(item);resolve(message.params);}};
      const timer=setTimeout(()=>item.fail(Object.assign(new Error('ローカルページの読込みがタイムアウトした。'),{code:'BROWSER_PAGE_TIMEOUT'})),45000);listeners.add(listener);waits.add(item);
    });},
    close(){socket.close();}
  };
}
async function render(jobs,statusDate,browser,format,timeout,onChart,diagnostics){
  const tempRoot=await mkdtemp(path.join(os.tmpdir(),'kobo-pm-render-'));
  let child,cdp,server,active=null;
  const results={};
  try{
    const mime={'.html':'text/html; charset=utf-8','.mjs':'text/javascript; charset=utf-8','.js':'text/javascript; charset=utf-8'};
    server=createServer(async(request,response)=>{
      try{
        if(request.method!=='GET'){response.writeHead(405);response.end();return;}
        const relative=decodeURIComponent(new URL(request.url,'http://127.0.0.1').pathname).replace(/^\//,'');
        const target=path.resolve(ROOT,relative);
        if(!relative.startsWith('assets/')||!target.startsWith(path.join(ROOT,'assets')+path.sep)||!mime[path.extname(target)]){response.writeHead(404);response.end();return;}
        const bytes=await readFile(target);
        response.writeHead(200,{'Content-Type':mime[path.extname(target)],'Cache-Control':'no-store','Content-Security-Policy':"default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; connect-src 'self'; font-src 'self' data:; object-src 'none'; base-uri 'none'"});response.end(bytes);
      }catch{response.writeHead(404);response.end();}
    });
    await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(0,'127.0.0.1',resolve);});
    child=spawn(browser,['--headless=new','--disable-gpu','--no-first-run','--no-default-browser-check','--disable-background-networking','--disable-component-update','--disable-extensions','--remote-debugging-address=127.0.0.1','--remote-debugging-port=0','--user-data-dir='+tempRoot,'about:blank'],{windowsHide:true,stdio:['ignore','ignore','pipe']});
    diagnostics.browser=browser;diagnostics.stderr='';
    child.stderr.on('data',data=>{diagnostics.stderr=(diagnostics.stderr+data.toString()).slice(-12000);});child.on('error',error=>{diagnostics.launchError=error.message;});
    child.on('exit',(code,signal)=>{diagnostics.exit={code,signal};});
    const devtools=path.join(tempRoot,'DevToolsActivePort');let endpoint='';
    for(let attempt=0;attempt<150;attempt++){
      if(child.exitCode!==null||diagnostics.launchError)throw Object.assign(new Error('ブラウザーを起動できない。パスと本機の実行権限を確認する。'),{code:'BROWSER_START_FAILED'});
      try{const [port,route]=(await readFile(devtools,'utf8')).trim().split(/\r?\n/);if(port&&route){endpoint=`ws://127.0.0.1:${port}${route}`;break;}}catch{}
      await delay(100);
    }
    if(!endpoint)throw Object.assign(new Error('ブラウザーの起動がタイムアウトした。ヘッドレス実行が許可されているか確認する。'),{code:'BROWSER_START_TIMEOUT'});
    cdp=await connectCDP(endpoint);
    diagnostics.browserVersion=await cdp.send('Browser.getVersion');
    const {targetId}=await cdp.send('Target.createTarget',{url:'about:blank'}),{sessionId}=await cdp.send('Target.attachToTarget',{targetId,flatten:true});
    cdp.on(message=>{if(message.method==='Runtime.consoleAPICalled'&&message.sessionId===sessionId){const value=message.params.args?.[0]?.value;if(typeof value==='string'&&value.startsWith('TASKOBO_STAGE ')){try{active={...active,...JSON.parse(value.slice(14))};}catch{}}}});
    await cdp.send('Runtime.enable',{},sessionId);await cdp.send('Page.enable',{},sessionId);
    const loaded=cdp.wait('Page.loadEventFired',sessionId);loaded.catch(()=>{});
    await cdp.send('Page.navigate',{url:`http://127.0.0.1:${server.address().port}/assets/runner.html`},sessionId);await loaded;
    const ready=await cdp.send('Runtime.evaluate',{expression:'window.__koboCompletion',awaitPromise:true,returnByValue:true},sessionId);
    const metadata=ready.result?.value;if(!metadata?.ok)throw new Error('ローカル runtime が準備できていない：'+(metadata?.error||ready.exceptionDetails?.text||'結果が返されなかった'));
    for(const job of jobs){
      active={id:job.id,title:job.title,taskIds:job.taskIds,characters:job.source.length,stage:'図表の送信'};
      let packet;
      try{
        const response=await cdp.send('Runtime.evaluate',{expression:'window.__taskoboRender('+JSON.stringify({...job,statusDate,format})+')',awaitPromise:true,returnByValue:true},sessionId,timeout);
        if(response.exceptionDetails)throw new Error(response.exceptionDetails.text||'ブラウザースクリプトで例外が発生した。');
        packet=response.result?.value;if(!packet)throw new Error('図表の結果が返されなかった。');
      }catch(error){packet={ok:false,error:{code:error.code||'BROWSER_CALL_FAILED',stage:active.stage,message:error.message,detail:error.stack}};}
      if(!packet.ok)diagnostics.errors.push({...active,...packet.error});
      if(packet.warning)diagnostics.errors.push({...active,...packet.warning});
      results[job.id]=await onChart(job,packet);
      if(!cdp.open||packet.error?.code==='BROWSER_CALL_TIMEOUT')break;
    }
    return {...metadata,charts:results};
  }catch(error){diagnostics.errors.push({...active,code:error.code||'BROWSER_FAILURE',stage:active?.stage||'ブラウザー準備',message:error.message,detail:error.stack});return {charts:results};}
  finally{
    if(cdp){if(cdp.open)await cdp.send('Browser.close',{},undefined,2000).catch(()=>{});cdp.close();}
    if(child&&child.exitCode===null){await delay(350);if(child.exitCode===null)child.kill();}
    if(/out of memory|allocation failed|oom-kill|fatal process out of memory/i.test(diagnostics.stderr||'')){
      for(const error of diagnostics.errors)if(error.code==='BROWSER_DISCONNECTED'||error.code==='BROWSER_START_FAILED'){
        error.code='BROWSER_MEMORY_FAILURE';error.message='ブラウザーログがメモリー不足を報告した。他のアプリを閉じ、次の値を小さくする： --page-size，または先に出力する： SVG。';
      }
    }
    if(server){server.closeAllConnections();await new Promise(resolve=>server.close(resolve));}
    const resolved=path.resolve(tempRoot),prefix=path.resolve(os.tmpdir())+path.sep+'kobo-pm-render-';
    if(resolved.startsWith(prefix))await rm(resolved,{recursive:true,force:true,maxRetries:6,retryDelay:250}).catch(()=>{});
  }
}
async function main(){
  const args=argumentsFor(process.argv.slice(2));
  if(args.help){console.log(usage);return;}
  requireNode();const {manifest,manifestSHA256}=await verifyRuntime();
  if(args.verify){const output=args.out?await verifyOutput(args.out):undefined;console.log(JSON.stringify({verified:true,message:'整合性の検証に成功。一部失敗の状況は次を確認する： output.status。',coreVersion:manifest.coreVersion,mermaidVersion:manifest.mermaidVersion,output},null,2));return;}
  if(args.doctor){const browser=await findBrowser(args.browser);console.log(JSON.stringify({ready:true,message:'Node、runtime とブラウザーパスの検査に成功。ブラウザーの実行は実際の描画時に検証する。',nodeVersion:process.version,browser,coreVersion:manifest.coreVersion,mermaidVersion:manifest.mermaidVersion},null,2));return;}
  if(!args.project||!args.out)throw new Error('指定が必要： --project と --out；実行： --help で使い方を確認する。');
  const input=path.resolve(args.project),projectBytes=await readFile(input),original=validateProject(JSON.parse(projectBytes.toString('utf8').replace(/^\uFEFF/,'')));
  let project=original,review=null,reviewBytes=null;
  if(args.review){
    reviewBytes=await readFile(path.resolve(args.review));review=JSON.parse(reviewBytes.toString('utf8').replace(/^\uFEFF/,''));
    if(review.schema!=='kobo.pm-review/v1'||review.projectId!==original.id||!Array.isArray(review.changes)||!review.candidateProject)throw new Error('レビュー形式に互換性がないか、入力プロジェクトと一致しない。');
    project=validateProject(review.candidateProject);if(project.id!==original.id)throw new Error('候補版でプロジェクトの識別子を変更することはできない。');
  }
  const plan=planViews(project,{pageSize:args['page-size'],group:args.group,from:args.from,to:args.to}),format=args.format||'all';
  const output=await beginOutput(args.out,{force:args.force,inputs:[input,args.review]});
  const diagnostics={schema:'taskobo.pm-diagnostics/v1',errors:[],nodeVersion:process.version},charts={};let packet={};
  try{
    for(const job of plan.jobs)await output.write('sources/'+job.id+(job.kind==='raci'?'.json':'.mmd'),job.source);
    if(format!=='sources'){
      let browser;try{browser=await findBrowser(args.browser);}catch(error){diagnostics.errors.push({code:'BROWSER_NOT_FOUND',stage:'ブラウザー準備',message:error.message});}
      if(browser)packet=await render(plan.jobs,project.statusDate,browser,format,args.timeout,async(job,chart)=>{
        const result={kind:job.kind,title:job.title,taskIds:job.taskIds,...(job.roleIds?{roleIds:job.roleIds}:{}),...(job.edges?{edges:job.edges}:{})};
        if(!chart.ok){result.failed=true;return result;}
        await output.write(job.id+'.svg',chart.svg);
        Object.assign(result,{width:chart.width,height:chart.height,type:chart.type,notes:chart.notes,png:false});
        if(chart.pngBase64){
          const png=Buffer.from(chart.pngBase64,'base64');if(!png.subarray(0,8).equals(Buffer.from([137,80,78,71,13,10,26,10])))throw new Error('PNG ファイルが無効：'+job.id);
          await output.write(job.id+'.png',png);result.png=true;result.pngSize=chart.pngSize;
        }
        return result;
      },diagnostics);
    }
    for(const job of plan.jobs)charts[job.id]=packet.charts?.[job.id]||{kind:job.kind,title:job.title,taskIds:job.taskIds,...(job.roleIds?{roleIds:job.roleIds}:{}),...(job.edges?{edges:job.edges}:{}),...(format==='sources'?{sourceOnly:true}:{failed:true})};
    const status=diagnostics.errors.length?'partial':'complete';
    const warnings=[...plan.notes,...diagnostics.errors.map(item=>(item.id||'環境')+'｜'+item.stage+'：'+item.message)];
    await output.write('project.snapshot.json',JSON.stringify(project,null,2)+'\n');
    if(review)await output.write('review.snapshot.json',JSON.stringify(review,null,2)+'\n');
    if(packet.profile)await output.write('profile.json',JSON.stringify(packet.profile,null,2)+'\n');
    await output.write('diagnostics.json',JSON.stringify(diagnostics,null,2)+'\n');
    await output.write('review.html',reviewPage(project,{candidate:!!review,review,format,warnings,jobs:plan.jobs.map(job=>({...job,...charts[job.id]}))}));
    const report={schema:'kobo.pm-render-report/v1',status,format,mode:review?'candidate-preview':'project-snapshot',projectId:project.id,statusDate:project.statusDate,updateId:review?.updateId||null,inputSHA256:sha(projectBytes),reviewInputSHA256:reviewBytes?sha(reviewBytes):null,coreVersion:manifest.coreVersion,mermaidVersion:manifest.mermaidVersion,runtimeManifestSHA256:manifestSHA256,summary:projectSummary(project),selection:plan.selection,charts,browserVersion:diagnostics.browserVersion,nodeVersion:process.version,fontNote:'フォントは本機で解決する。OS間でピクセル単位の差が生じる場合がある。'};
    const destination=await output.commit(report);
    console.log(JSON.stringify({output:destination,page:path.join(destination,'review.html'),status,format,projectId:project.id,tasks:plan.selection.taskIds.length,pages:plan.jobs.length,errors:diagnostics.errors.map(({id,code,stage,message})=>({id,code,stage,message}))},null,2));
    if(status==='partial')process.exitCode=2;
  }catch(error){await output.abort();throw error;}
}
if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url))main().catch(error=>{console.error('Taskobo Diagrams：'+error.message);process.exitCode=1;});
