import { readFile, realpath, stat } from 'node:fs/promises';
import path from 'node:path';
import { createHash } from 'node:crypto';

const PROJECT_SCHEMA = 'kobo.pm-project/v1';
const UPDATE_SCHEMA = 'kobo.pm-update/v1';
const TASK_FIELDS = new Set(['forecast', 'status', 'actualFinish', 'responsibilities', 'title', 'acceptance', 'dependsOn', 'archived']);
const ACTION_FIELDS = new Set(['title', 'ownerRoleId', 'dueDate', 'status']);
const DECISION_FIELDS = new Set(['title', 'status']);
const HASH = /^[a-f0-9]{64}$/;
const own = (object, key) => Object.hasOwn(object, key);
const fail = (message) => { throw new Error(message); };

function object(value, label) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) fail(`${label}はオブジェクトである必要がある`);
}

function text(value, label) {
  if (typeof value !== 'string' || !value.trim()) fail(`${label}は空でないテキストである必要がある`);
  if(value.length>10000)fail(`${label}は上限を超えている： 10000 文字。詳細な説明は出典資料に分けて保存する`);
  if(/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/u.test(value))fail(`${label}に対応外の制御文字が含まれる`);
}

function id(value, label) {
  text(value, label);
  if (value.length > 128 || value.trim() !== value || /[\r\n,]/u.test(value) || value.startsWith('--')) fail(`${label}の形式が無効。使用できない文字： ASCII カンマ、改行、前後の空白。また、次の接頭辞も使用できない： -- 。文字数上限： 128 文字`);
}

function list(value, label) {
  if (!Array.isArray(value)) fail(`${label}は配列である必要がある`);
}

function unique(items, label) {
  list(items, label);
  const ids = new Set();
  for (const item of items) {
    object(item, label);
    id(item.id, `${label} ID`);
    if (ids.has(item.id)) fail(`${label} ID が重複：${item.id}`);
    ids.add(item.id);
  }
  return ids;
}

export function validDate(value, label = '日付') {
  if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}$/u.test(value)) fail(`${label}の形式： YYYY-MM-DD`);
  const parsed = new Date(`${value}T00:00:00.000Z`);
  if (!Number.isFinite(parsed.getTime()) || parsed.toISOString().slice(0, 10) !== value) fail(`${label}は有効な暦日ではない：${value}`);
  return value;
}

function range(value, label) {
  object(value, label);
  validDate(value.start, `${label}の開始日`);
  validDate(value.finish, `${label}の終了日`);
  if (value.start > value.finish) fail(`${label}は開始日が終了日より遅い`);
}

function action(value, roleIds) {
  text(value.title, `アクション ${value.id} の名称`);
  if (!roleIds.has(value.ownerRoleId)) fail(`アクション ${value.id} の担当者が存在しない：${value.ownerRoleId}`);
  validDate(value.dueDate, `アクション ${value.id} の期限`);
  if (!['open', 'done'].includes(value.status)) fail(`アクション ${value.id} の状態が無効`);
}

function decision(value) {
  text(value.title, `決定事項 ${value.id} の名称`);
  if (!['pending', 'approved', 'rejected', 'deferred'].includes(value.status)) fail(`決定事項 ${value.id} の状態が無効`);
}

export function validateProject(project) {
  object(project, 'プロジェクト');
  if (project.schema === 'taskobo.pm-draft/v1') fail('初期化草稿のため、先に不足情報を確認する： questions.md 。整理担当： AI 出力形式： project.json，その後に実行： check または図表生成。');
  if (project.schema !== PROJECT_SCHEMA) fail(`プロジェクト schema の形式： ${PROJECT_SCHEMA}`);
  id(project.id, 'プロジェクト ID');
  text(project.name, 'プロジェクト名');
  validDate(project.statusDate, 'プロジェクトの集計基準日');
  const roleIds = unique(project.roles, '役割');
  if (roleIds.size < 1 || roleIds.size > 32) fail('プロジェクトに必要な範囲： 1–32 役割');
  for (const role of project.roles) text(role.name, `役割 ${role.id} の名称`);
  const groupIds = unique(project.groups, 'グループ');
  if (!groupIds.size) fail('プロジェクトには一つ以上のグループが必要だ');
  for (const group of project.groups) text(group.name, `グループ ${group.id} の名称`);
  const taskIds = unique(project.tasks, 'タスク');
  if (taskIds.size < 1 || taskIds.size > 300) fail('プロジェクトに必要な範囲： 1–300 タスク。大規模案件は成果物の範囲に沿って独立したプロジェクトに分ける');
  for (const task of project.tasks) {
    text(task.title, `タスク ${task.id} の名称`);
    text(task.acceptance, `タスク ${task.id} の受入条件`);
    if(own(task,'archived')&&typeof task.archived!=='boolean')fail(`タスク ${task.id} の archived は真偽値である必要がある`);
    if (!groupIds.has(task.groupId)) fail(`タスク ${task.id} のグループが存在しない`);
    object(task.responsibilities, `タスク ${task.id} の責任分担`);
    let accountable = 0;
    let responsible = 0;
    for (const [roleId, assignment] of Object.entries(task.responsibilities)) {
      if (!roleIds.has(roleId)) fail(`タスク ${task.id} に存在しない役割への参照がある：${roleId}`);
      if (!['A', 'R', 'C', 'I', 'A/R', ''].includes(assignment)) fail(`タスク ${task.id} の責任コードが無効：${assignment}`);
      if (assignment === 'A' || assignment === 'A/R') accountable++;
      if (assignment === 'R' || assignment === 'A/R') responsible++;
    }
    if (accountable !== 1 || responsible < 1) fail(`タスク ${task.id} に必要な最終責任者は一人のみ： A，。実行担当者は一人以上： R`);
    range(task.baseline, `タスク ${task.id} の承認済み基準`);
    range(task.forecast, `タスク ${task.id} の現在の予測`);
    if (!['planned', 'active', 'done'].includes(task.status)) fail(`タスク ${task.id} の状態が無効`);
    if (task.status === 'done') {
      validDate(task.actualFinish, `タスク ${task.id} の実績完了日`);
      if (task.actualFinish > project.statusDate) fail(`タスク ${task.id} の実績完了日が集計基準日より遅い`);
    } else if (task.actualFinish !== null) fail(`未完了タスク ${task.id} の実績完了日に必要な値： null`);
    list(task.dependsOn, `タスク ${task.id} の依存関係`);
    if (new Set(task.dependsOn).size !== task.dependsOn.length) fail(`タスク ${task.id} の依存関係が重複している`);
    for (const predecessor of task.dependsOn) {
      if (!taskIds.has(predecessor)) fail(`タスク ${task.id} の先行タスクが存在しない：${predecessor}`);
      if (predecessor === task.id) fail(`タスク ${task.id} は自分自身に依存できない`);
    }
  }
  const tasksById = new Map(project.tasks.map((task) => [task.id, task]));
  const visited = new Set();
  const visiting = new Set();
  function visit(taskId) {
    if (visiting.has(taskId)) fail(`タスクの依存関係に循環がある：${taskId}`);
    if (visited.has(taskId)) return;
    visiting.add(taskId);
    for (const predecessor of tasksById.get(taskId).dependsOn) visit(predecessor);
    visiting.delete(taskId);
    visited.add(taskId);
  }
  for (const taskId of taskIds) visit(taskId);
  unique(project.actions, 'アクション');
  for (const item of project.actions) action(item, roleIds);
  unique(project.decisions, '決定事項');
  for (const item of project.decisions) decision(item);
  unique(project.appliedUpdates, '適用済み更新');
  for (const update of project.appliedUpdates) {
    if (!HASH.test(update.sha256)) fail(`適用済み更新 ${update.id} の SHA-256 が無効`);
    validDate(update.asOf, `適用済み更新 ${update.id} の集計基準日`);
    if (update.asOf > project.statusDate) fail(`適用済み更新 ${update.id} の集計基準日が現在のプロジェクトより遅い`);
    list(update.changeIds, `適用済み更新 ${update.id} の変更 ID`);
    if (!update.changeIds.length || new Set(update.changeIds).size !== update.changeIds.length) fail(`適用済み更新 ${update.id} の変更 ID が空欄または重複している`);
    for (const changeId of update.changeIds) id(changeId, '適用済みの変更 ID');
    unique(update.sources, `適用済み更新 ${update.id} の出典`);
    for (const source of update.sources) {
      text(source.file, '適用済み出典パス');
      if (!HASH.test(source.sha256)) fail('適用済み出典の SHA-256 が無効');
    }
  }
  return project;
}

function canonical(value) {
  if (value === null || typeof value !== 'object') return JSON.stringify(value);
  if (Array.isArray(value)) return `[${value.map(canonical).join(',')}]`;
  return `{${Object.keys(value).sort().map((key) => `${JSON.stringify(key)}:${canonical(value[key])}`).join(',')}}`;
}

const equal = (left, right) => canonical(left) === canonical(right);
const sha256 = (value) => createHash('sha256').update(value).digest('hex');

function validateUpdate(update) {
  object(update, '更新');
  if (update.schema !== UPDATE_SCHEMA) fail(`更新 schema の形式： ${UPDATE_SCHEMA}`);
  id(update.id, '更新 ID');
  validDate(update.asOf, '更新の集計基準日');
  const sourceIds = unique(update.sources, '出典');
  if (!sourceIds.size) fail('更新には一つ以上の出典が必要だ');
  for (const source of update.sources) {
    text(source.file, `出典 ${source.id} のファイルパス`);
    if (own(source, 'sha256') && !HASH.test(source.sha256)) fail(`出典 ${source.id} の SHA-256 の形式： 64 桁の小文字16進数`);
  }
  unique(update.changes, '変更');
  if (!update.changes.length) fail('更新には一つ以上の変更が必要だ');
  const fields = new Set();
  const additions = new Set();
  for (const change of update.changes) {
    if (!own(change, 'value')) fail(`変更 ${change.id} 不足： value`);
    const [entity, operation, extra] = typeof change.kind === 'string' ? change.kind.split('.') : [];
    if (extra || !['task', 'action', 'decision'].includes(entity) || !['set', 'add'].includes(operation)) fail(`変更 ${change.id} の kind に対応していない`);
    if (operation === 'set') {
      id(change.targetId, `変更 ${change.id} の対象 ID`);
      if (change.field === 'baseline' || String(change.field).startsWith('baseline.')) fail('通常の更新では承認済み基準を変更できない baseline；承認済み基準の改訂は別途行い、承認根拠と版を保持する');
      const allowed = entity === 'task' ? TASK_FIELDS : entity === 'action' ? ACTION_FIELDS : DECISION_FIELDS;
      if (!allowed.has(change.field)) fail(`変更 ${change.id} に対応していないフィールドがある：${change.field}`);
      if (!own(change, 'expected')) fail(`変更 ${change.id} 不足： expected 現在値`);
      const fieldKey = canonical([entity, change.targetId, change.field]);
      if (fields.has(fieldKey)) fail(`一つの更新で同じフィールドの変更が重複している：${change.targetId}.${change.field}`);
      fields.add(fieldKey);
    } else {
      object(change.value, `変更 ${change.id} の追加対象`);
      id(change.value.id, `変更 ${change.id} の追加対象 ID`);
      if (['targetId', 'field', 'expected'].some((key) => own(change, key))) fail(`追加変更 ${change.id} に含めてはならない： targetId、field または expected`);
      const additionKey = canonical([entity, change.value.id]);
      if (additions.has(additionKey)) fail(`一つの更新で追加対象が重複している：${change.value.id}`);
      additions.add(additionKey);
    }
    list(change.evidence, `変更 ${change.id} の根拠`);
    if (!change.evidence.length) fail(`変更 ${change.id} には一つ以上の原文引用が必要だ`);
    for (const evidence of change.evidence) {
      object(evidence, `変更 ${change.id} の根拠`);
      if (!sourceIds.has(evidence.sourceId)) fail(`変更 ${change.id} の出典が存在しない：${evidence.sourceId}`);
      text(evidence.quote, `変更 ${change.id} の原文引用`);
    }
  }
}

function within(parent, child) {
  const relative = path.relative(parent, child);
  return relative !== '' && !path.isAbsolute(relative) && relative !== '..' && !relative.startsWith(`..${path.sep}`);
}

export async function prepareUpdate(project, update, { updatePath } = {}) {
  validateProject(project);
  validateUpdate(update);
  if (!updatePath) fail('出典を検証するには更新ファイルのパスが必要だ updatePath');
  const base = await realpath(path.dirname(path.resolve(updatePath)));
  const sourceText = new Map();
  const sources = [];
  for (const source of update.sources) {
    if (path.isAbsolute(source.file) || /^[a-zA-Z]:/u.test(source.file) || source.file.includes('\\')) fail(`出典 ${source.id} にはディレクトリ内の相対パスを使用する（区切り文字： /）`);
    const resolved = path.resolve(base, source.file);
    if (!within(base, resolved)) fail(`出典 ${source.id} が更新ディレクトリツリー外を指す`);
    const physical = await realpath(resolved);
    if (!within(base, physical)) fail(`出典 ${source.id} の実体パスが更新ディレクトリツリー外を指す`);
    const details = await stat(physical);
    if (!details.isFile() || details.size > 2 * 1024 * 1024) fail(`出典 ${source.id} の形式： 2 MiB 以下のテキストファイル`);
    const bytes = await readFile(physical);
    let content;
    try { content = new TextDecoder('utf-8', { fatal: true }).decode(bytes); } catch { fail(`出典 ${source.id} は無効な UTF-8 テキスト`); }
    if (content.includes('\0')) fail(`出典 ${source.id} にバイナリのヌル文字が含まれる`);
    const hash = sha256(bytes);
    if (own(source, 'sha256') && source.sha256 !== hash) fail(`出典 ${source.id} の SHA-256 がファイルと一致しない`);
    sources.push({ id: source.id, file: source.file, sha256: hash });
    sourceText.set(source.id, content);
  }
  for (const change of update.changes) {
    for (const evidence of change.evidence) {
      if (!sourceText.get(evidence.sourceId).includes(evidence.quote)) fail(`変更 ${change.id} の引用が出典に見つからない： ${evidence.sourceId} の原文`);
    }
  }
  const updateHash = sha256(canonical({ update, sources }));
  const recorded = project.appliedUpdates.find((item) => item.id === update.id);
  if (recorded && recorded.sha256 !== updateHash) fail(`更新 ID ${update.id} は既に存在するが内容や出典が変更されている。新しい更新識別子を使用する： ID`);
  if (recorded && recorded.changeIds.some((changeId) => !update.changes.some((change) => change.id === changeId))) fail(`更新 ${update.id} の適用済み変更記録が一致しない`);
  return { update: structuredClone(update), updateHash, sources };
}

export function applyUpdate(project, prepared, selectedIds) {
  validateProject(project);
  object(prepared, '検証済み更新');
  const { update, updateHash, sources } = prepared;
  validateUpdate(update);
  if (!HASH.test(updateHash)) fail('検証済み更新に有効な内容ハッシュがない。先に実行する： prepareUpdate');
  if (sha256(canonical({ update, sources })) !== updateHash) fail('検証済み更新の内容が変更されている。再実行する： prepareUpdate');
  list(selectedIds, '明示的に選択された変更 ID');
  if (new Set(selectedIds).size !== selectedIds.length) fail('明示的に選択された変更 ID が重複している');
  const selected = new Set(selectedIds);
  for (const changeId of selected) if (!update.changes.some((change) => change.id === changeId)) fail(`存在しない変更が選択された： ID：${changeId}`);
  const candidate = structuredClone(project);
  let record = candidate.appliedUpdates.find((item) => item.id === update.id);
  if (record && record.sha256 !== updateHash) fail(`更新 ID ${update.id} は既に存在するが内容や出典が変更されている。新しい更新識別子を使用する： ID`);
  const previouslyApplied = new Set(record?.changeIds ?? []);
  const changes = update.changes.filter((change) => selected.has(change.id) && !previouslyApplied.has(change.id));
  if (!changes.length) return candidate;
  if (update.asOf < project.statusDate) fail(`更新の集計基準日 ${update.asOf} が現在のプロジェクトの集計基準日より早い ${project.statusDate}`);
  for (const change of changes) {
    const [entity, operation] = change.kind.split('.');
    const collection = entity === 'task' ? candidate.tasks : entity === 'action' ? candidate.actions : candidate.decisions;
    if (operation === 'add') {
      if (collection.some((item) => item.id === change.value.id)) fail(`追加対象 ${entity} の ID が既に存在する：${change.value.id}`);
      collection.push(structuredClone(change.value));
    } else {
      const target = collection.find((item) => item.id === change.targetId);
      if (!target) fail(`変更 ${change.id} の対象が存在しない：${change.targetId}`);
      const current = entity === 'task' && change.field === 'archived' ? target.archived ?? false : target[change.field];
      if (!equal(current, change.expected)) fail(`変更 ${change.id} の expected が現在値と競合する：${change.targetId}.${change.field}`);
      target[change.field] = structuredClone(change.value);
    }
  }
  candidate.statusDate = update.asOf;
  if (!record) {
    record = { id: update.id, sha256: updateHash, asOf: update.asOf, changeIds: [], sources: structuredClone(sources) };
    candidate.appliedUpdates.push(record);
  }
  record.changeIds.push(...changes.map((change) => change.id));
  return validateProject(candidate);
}

export function reviewUpdate(project, prepared) {
  const appliedChangeIds = [...(project.appliedUpdates.find((item) => item.id === prepared.update.id)?.changeIds ?? [])];
  const applied = new Set(appliedChangeIds);
  const pendingChangeIds = prepared.update.changes.filter((change) => !applied.has(change.id)).map((change) => change.id);
  const candidateProject = applyUpdate(project, prepared, pendingChangeIds);
  return {
    schema: 'kobo.pm-review/v1', projectId: project.id, projectName: project.name,
    updateId: prepared.update.id, asOf: prepared.update.asOf, updateHash: prepared.updateHash,
    sources: structuredClone(prepared.sources), appliedChangeIds, pendingChangeIds,
    changes: prepared.update.changes.map((change) => ({ ...structuredClone(change), alreadyApplied: applied.has(change.id) })),
    candidateProject,
  };
}
