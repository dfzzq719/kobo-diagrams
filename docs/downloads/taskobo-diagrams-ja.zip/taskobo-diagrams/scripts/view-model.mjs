import {validateProject} from './project.mjs';

export const escapeHTML=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
// Business text is data. Generated IDs and syntax never come from user input.
const mermaidText=value=>String(value??'').replace(/[\r\n\t]/g,' ').replace(/[&<>"'\[\]{}:;`%#\\]/g,c=>'#'+c.codePointAt(0)+';');
const wrap=value=>{
  const lines=[];let line='',width=0;
  for(const char of String(value)){const units=/[\x20-\x7e]/.test(char)?.55:1;if(width+units>15&&!/[，。、；：！？）》】]/u.test(char)){lines.push(line);line='';width=0;}line+=char;width+=units;}
  if(line.length<4&&lines.length){const tail=lines.pop(),split=Math.max(1,tail.length-5);lines.push(tail.slice(0,split));line=tail.slice(split)+line;}
  lines.push(line);return lines.map(mermaidText).join('<br/>');
};
const single=value=>String(value??'').replace(/[\r\n\t]/g,' ').replace(/[<>:;"`%#\\]/g,c=>({'<':'＜','>':'＞',':':'：',';':'；','"':'＂','`':'＇','%':'％','#':'＃','\\':'／'}[c]));
const days=(a,b)=>Math.round((Date.parse(a+'T00:00:00Z')-Date.parse(b+'T00:00:00Z'))/86400000);

export function projectViews(project,{validate=true,vertical=false}={}){
  if(validate)validateProject(project);
  const taskIndex=new Map(project.tasks.map((task,index)=>[task.id,index+1]));
  const wbs=['flowchart '+(vertical?'TB':'LR'),`  P["${wrap(project.name)}<br/>集計基準日 ${project.statusDate}"]:::anchor`,'  %% 包含関係を示す図であり、依存関係や受入完了を意味しない。'];
  [...project.groups].reverse().forEach((group,index)=>{
    const tasks=project.tasks.filter(task=>task.groupId===group.id);
    if(!tasks.length)return;
    if(!vertical)wbs.push(`  subgraph G${index+1}["${mermaidText(group.name)}"]`);
    tasks.forEach(task=>wbs.push(`    T${taskIndex.get(task.id)}["${wrap(task.id+' '+task.title)}<br/>${wrap('受入条件：'+task.acceptance)}"]:::normal`));
    if(!vertical)wbs.push('  end');
    if(vertical)tasks.forEach(task=>wbs.push(`  P --> T${taskIndex.get(task.id)}`));
    else{
      wbs.push(`  P --> T${taskIndex.get(tasks[0].id)}`);
      for(let i=1;i<tasks.length;i++)wbs.push(`  T${taskIndex.get(tasks[i-1].id)} ~~~ T${taskIndex.get(tasks[i].id)}`);
    }
  });
  const raci={schema:'taskobo.table/v1',kind:'raci',title:project.name+'｜責任分担｜'+project.statusDate,columns:[{key:'work',label:'作業パッケージ・成果物',width:330},...project.roles.map((role,index)=>({key:'role'+index,label:({'プロジェクトスポンサー':'スポンサー','プロジェクトマネージャー':'PM'})[role.name]||(role.name.length>5?role.name.replace(/(責任者|ベンダー)$/u,'\n$1'):role.name),width:155}))],rows:project.tasks.map(task=>({work:task.id+' '+task.title,...Object.fromEntries(project.roles.map((role,index)=>['role'+index,task.responsibilities[role.id]||'']))}))};
  const items=project.tasks.map((task,index)=>({baseline:'b'+index,current:'c'+index,baselineEnd:task.baseline.finish,finish:task.actualFinish||task.forecast.finish,stage:task.status==='done'?'done':'forecast'}));
  const schedule=['gantt',`  title ${single(project.name)}｜基準と実績／予測`, '  dateFormat YYYY-MM-DD','  axisFormat %m/%d','  tickInterval 1week','  todayMarker off',`  %% taskobo-gantt-status ${JSON.stringify({schema:'taskobo.gantt-status/v1',calendar:'calendar-days',asOf:project.statusDate,statusMarker:'status_date',items,plannedTasks:[]})}`,'  section 固定の集計基準日',`  集計基準日 ${project.statusDate} :milestone, status_date, ${project.statusDate}, 0d`];
  project.tasks.forEach((task,index)=>{
    const finish=task.actualFinish||task.forecast.finish,delta=days(finish,task.baseline.finish);
    const stage=task.status==='done'?'実績':'予測',deltaText=delta>0?'基準から遅延'+delta+'日':delta<0?'基準より早期'+(-delta)+'日':'基準どおり';
    schedule.push(`  section ${single(task.id+' '+task.title)}`,`  基準 :b${index}, ${task.baseline.start}, ${task.baseline.finish}`,task.status==='done'?`  実績完了 ${finish}／${deltaText} :done, milestone, c${index}, ${finish}, ${finish}`:`  ${stage}／${deltaText} :active, c${index}, ${task.forecast.start}, ${finish}`);
  });
  return {wbs:wbs.join('\n')+'\n',raci:JSON.stringify(raci,null,2)+'\n',schedule:schedule.join('\n')+'\n'};
}

export function projectSummary(project){
  const complete=project.tasks.filter(task=>task.status==='done').length;
  const delayed=project.tasks.filter(task=>(task.actualFinish||task.forecast.finish)>task.baseline.finish);
  const overdue=project.tasks.filter(task=>task.status!=='done'&&task.baseline.finish<project.statusDate);
  const byId=new Map(project.tasks.map(task=>[task.id,task]));
  const dependencyConflicts=project.tasks.flatMap(task=>task.dependsOn.flatMap(id=>{
    const predecessor=byId.get(id),finish=predecessor.actualFinish||predecessor.forecast.finish;
    return task.forecast.start<finish?[{taskId:task.id,predecessorId:id,predecessorFinish:finish,taskForecastStart:task.forecast.start}]:[];
  }));
  const staleForecastTaskIds=project.tasks.filter(task=>!task.archived&&task.status!=='done'&&task.forecast.finish<project.statusDate).map(task=>task.id);
  return {staleForecastTaskIds,archivedTaskIds:project.tasks.filter(task=>task.archived).map(task=>task.id),statusDate:project.statusDate,taskCount:project.tasks.length,completed:complete,delayedTaskIds:delayed.map(task=>task.id),overdueTaskIds:overdue.map(task=>task.id),dependencyConflicts,openActions:project.actions.filter(item=>item.status!=='done'),pendingDecisions:project.decisions.filter(item=>item.status==='pending')};
}

export function reviewPage(project,{candidate=false,review=null,jobs=null,format='all',warnings=[]}={}){
  const s=projectSummary(project),esc=escapeHTML;
  const list=(items,fn)=>items.length?'<ul>'+items.map(item=>'<li>'+fn(item)+'</li>').join('')+'</ul>':'<p class="quiet">記録はまだない。</p>';
  const changes=review?.changes||review?.proposals||[];
  const fieldNames={forecast:'完了予測',status:'状態',actualFinish:'実績完了日',responsibilities:'責任分担',title:'名称',acceptance:'受入条件',archived:'アーカイブ状態',dependsOn:'先行依存関係',ownerRoleId:'責任者',dueDate:'期限'};
  const kindNames={'task.add':'作業パッケージの追加','task.set':'作業パッケージの変更','action.add':'アクションの追加','action.set':'アクションの変更','decision.add':'要判断事項の追加','decision.set':'決定事項の変更'};
  const statuses={planned:'計画中',active:'進行中',done:'完了',open:'未完了',pending:'判断待ち',approved:'承認済み',rejected:'却下',deferred:'保留'};
  const roleName=id=>project.roles.find(role=>role.id===id)?.name||id;
  const responsibilityNames={A:'最終責任',R:'実行',C:'相談',I:'情報共有','A/R':'最終責任・実行','':'未割当て'};
  const valueText=(value,item)=>{
    if(value===null||value===undefined)return '未記録';
    if(item.field==='responsibilities')return Object.entries(value).map(([id,code])=>roleName(id)+'：'+responsibilityNames[code]).join('；');
    if(item.field==='ownerRoleId')return roleName(value);
    if(Array.isArray(value))return value.length?value.map(id=>{const task=project.tasks.find(task=>task.id===id);return task?id+' '+task.title:id;}).join('；'):'なし';
    if(typeof value==='object'){
      if(value.start&&value.finish)return value.start+' ～ '+value.finish;
      const parts=[];
      if(value.title)parts.push(value.title);
      if(value.ownerRoleId)parts.push('担当者：'+roleName(value.ownerRoleId));
      if(value.dueDate)parts.push('期限：'+value.dueDate);
      if(value.status)parts.push('状態：'+(statuses[value.status]||value.status));
      return parts.length?parts.join('；'):'詳細はレビュー原資料を参照';
    }
    return statuses[value]||String(value);
  };
  const changeList=list(changes,item=>'<strong>'+esc(item.id)+' '+esc(item.targetId||item.value?.id||'')+'</strong> '+esc(fieldNames[item.field]||kindNames[item.kind]||'資料の変更')+(Object.hasOwn(item,'expected')?'<br/>変更前：'+esc(valueText(item.expected,item)):'')+'<br/>提案：'+esc(valueText(item.value,item))+(item.alreadyApplied?' <span class="quiet">（適用済み）</span>':'')+(item.evidence||[]).map(evidence=>'<blockquote>根拠 '+esc(evidence.sourceId)+'：'+esc(evidence.quote)+'</blockquote>').join(''));
  const dependencies=list(s.dependencyConflicts,item=>esc(item.taskId)+'の開始予測（'+esc(item.taskForecastStart)+'）が、先行作業'+esc(item.predecessorId)+'の終了日（'+esc(item.predecessorFinish)+'）より早い。PMが調整を評価・確認する。自動再配置は行っていない。');
  const planned=jobs||['wbs','raci','schedule'].map(id=>({id,kind:id,title:id}));
  const descriptions={wbs:'包含関係は依存関係を表さない。短いラベルに対応する受入条件の全文は下の明細を参照する。',raci:'A 最終責任 · R 実行 · C 相談 · I 情報共有 · A/R 最終責任・実行。役割を分割したページは合わせて読む。',schedule:'承認済み基準を保持する。実績開始日が不明なら完了日だけを示す。期限切れの予測は元の日付を保持し、更新を促す。',dependencies:'矢印は先行作業から後続作業へ向かう。ページ間は同じIDで関連付ける。'};
  const figures=planned.map(job=>'<section id="'+job.id+'"><h2>'+esc(job.title)+'</h2><p>'+descriptions[job.kind]+'</p><p class="meta">'+(format==='sources'||job.failed?'':'<a href="'+job.id+'.svg">SVGを開く</a> · ')+(format==='all'&&!job.failed&&job.png!==false?'<a href="'+job.id+'.png">PNGを開く</a> · ':'')+'<a href="sources/'+job.id+(job.kind==='raci'?'.json':'.mmd')+'">編集用ソース</a></p>'+(format==='sources'?'<p>ソースのみを生成した。ブラウザーでの描画は実行していない。</p>':job.failed?'<p class="notice">この図の生成に失敗した。診断報告を参照する。ソースは保持している。</p>':'<figure><img src="'+job.id+(format==='all'&&job.png!==false?'.png':'.svg')+'" alt="'+esc(job.title)+'"></figure>')+'</section>').join('');
  const details='<section id="tasks"><h2>作業パッケージの全明細</h2><p>役割：'+project.roles.map(role=>esc(role.id+' '+role.name)).join('；')+'</p>'+project.tasks.map(task=>'<details><summary>'+esc(task.id+' '+task.title)+(task.archived?'（アーカイブ済み）':'')+'</summary><p>受入条件：'+esc(task.acceptance)+'</p><p>先行作業：'+esc(task.dependsOn.join('、')||'なし')+'；基準：'+esc(task.baseline.start+' ～ '+task.baseline.finish)+'；予測：'+esc(task.forecast.start+' ～ '+task.forecast.finish)+'</p></details>').join('')+'</section>';

  return `<!doctype html><html lang="ja"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta http-equiv="Content-Security-Policy" content="default-src 'none'; img-src 'self' data:; style-src 'unsafe-inline'; base-uri 'none'; form-action 'none'"><title>${esc(project.name)}｜プロジェクト更新パッケージ</title><style>body{margin:0;background:#FFFEFA;color:#0D2046;font:16px/1.7 system-ui,'Noto Sans JP','Yu Gothic',Meiryo,sans-serif}main{max-width:1120px;margin:auto;padding:40px 24px 72px}header{border-top:5px solid #1456D9;padding:24px 0}h1{font-size:clamp(26px,5vw,40px);line-height:1.25;margin:8px 0 16px;overflow-wrap:anywhere}h2{font-size:24px}h3{font-size:18px}.eyebrow,.quiet{color:#52637A}.notice{padding:16px 20px;border:1px solid #bb883a;background:#fff4dc;border-radius:0}.metrics{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin:24px 0}.metric{padding:16px;background:#fff;border:1px solid #D9DEE8;border-radius:0}.metric strong{display:block;font-size:30px;line-height:1.3}.metric span{font-size:14px}section{margin:36px 0}figure{margin:12px 0 0;padding:16px;background:#fff;border:1px solid #D9DEE8;border-radius:0}img{width:100%;height:auto;display:block}a{color:#1456D9;text-underline-offset:3px}li{margin:6px 0;overflow-wrap:anywhere}blockquote{margin:8px 0;padding-left:14px;border-left:3px solid #bbb;color:#52637A}nav{display:flex;flex-wrap:wrap;gap:18px}.meta{font-size:14px}footer{border-top:1px solid #D9DEE8;margin-top:36px;padding-top:18px}@media(max-width:600px){main{padding:20px 14px 40px}.metrics{grid-template-columns:repeat(2,1fr)}figure{padding:6px}h2{font-size:22px}}</style></head><body><main><header><div class="eyebrow">Taskobo Diagrams · プロジェクト資料の更新パッケージ</div><h1>${esc(project.name)}</h1><p>集計基準日：${esc(project.statusDate)}。PMが判断、対話、成果の実現に集中する。</p>${candidate?'<p class="notice"><strong>更新案のプレビュー・未確認。</strong>提案候補から生成したページで、元のプロジェクトは保持している。各変更をレビューして適用する。</p>':'<p class="notice">提供されたプロジェクト情報の静的な表示だ。受入条件、予測日、要判断事項の表示は承認を意味しない。</p>'}<nav><a href="#summary">週次サマリー</a><a href="#wbs">作業分解</a><a href="#raci">責任分担</a><a href="#schedule">工程表</a><a href="#dependencies">依存関係</a><a href="#tasks">全明細</a></nav></header><div class="metrics"><div class="metric"><strong>${s.taskCount}</strong><span>作業パッケージ</span></div><div class="metric"><strong>${s.completed}</strong><span>完了記録</span></div><div class="metric"><strong>${s.delayedTaskIds.length}</strong><span>基準より終了が遅い</span></div><div class="metric"><strong>${s.pendingDecisions.length}</strong><span>要判断事項</span></div></div><section id="summary"><h2>週次サマリー</h2>${warnings.length?'<p class="notice">'+warnings.map(esc).join('<br/>')+'</p>':''}<p>${esc(project.statusDate)}時点で、${s.taskCount}作業パッケージ中${s.completed}件を完了と記録している。未完了の${s.overdueTaskIds.length}件が基準終了日を過ぎている。</p><h3>アクション</h3>${list(s.openActions,item=>esc(item.id+' '+item.title)+'；担当者：'+esc(project.roles.find(role=>role.id===item.ownerRoleId)?.name||item.ownerRoleId)+'；期限：'+esc(item.dueDate))}<h3>PMが進める決定事項</h3>${list(s.pendingDecisions,item=>esc(item.id+' '+item.title))}<h3>期限切れの予測・PMの確認が必要</h3>${list(s.staleForecastTaskIds,id=>esc(id)+" の予測終了日は過ぎている。元の日付を保持し、自動延長していない。")}<h3>依存関係の日付競合</h3>${dependencies}${review?'<h3>今回の変更提案</h3>'+changeList:''}</section>${figures}${details}<footer><p>各ページは同じプロジェクト状態から生成する。元の責任、基準、依存関係は変更しない。原文と依存関係の保存先： <a href="project.snapshot.json">プロジェクトスナップショット</a>。描画処理の記録： <a href="report.json">生成報告</a>。${review?'<a href="review.snapshot.json">レビュー原資料</a>に今回の根拠と変更記録を保持している。':''}</p></footer></main></body></html>`;
}
