import {readFile,mkdir,writeFile} from 'node:fs/promises';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {validDate} from './project.mjs';

export function parseCSV(text){
  const rows=[];let row=[],cell='',quoted=false,closed=false;
  text=text.replace(/^\uFEFF/,'').replace(/\r\n/g,'\n');
  const push=()=>{row.push(cell);cell='';closed=false;};
  for(let i=0;i<text.length;i++){
    const c=text[i];
    if(quoted){if(c==='"'){if(text[i+1]==='"'){cell+='"';i++;}else{quoted=false;closed=true;}}else cell+=c;}
    else if(c===','){push();}
    else if(c==='\n'){push();if(row.some(value=>value.trim()))rows.push(row);row=[];}
    else if(c==='"'&&!cell&&!closed)quoted=true;
    else{if(closed)throw new Error('CSV 閉じ引用符の直後にはカンマまたは改行が必要だ。');if(c==='"')throw new Error('CSV フィールド内の二重引用符は、フィールド全体を引用符で囲み、二重引用符を二つ続けて記述する。');cell+=c;}
  }
  if(quoted)throw new Error('CSV 閉じていない二重引用符がある。');
  if(cell||row.length||closed){push();if(row.some(value=>value.trim()))rows.push(row);}
  return rows;
}
const splitMD=line=>line.trim().replace(/^\|/,'').replace(/(?<!\\)\|$/,'').split(/(?<!\\)\|/).map(value=>value.trim().replace(/\\\|/g,'|'));
export function parseMarkdown(text){
  const lines=text.replace(/^\uFEFF/,'').split(/\r?\n/),tables=[];
  for(let i=0;i<lines.length-1;i++){
    if(!lines[i].includes('|')||!/^\s*\|?\s*:?-{3,}/.test(lines[i+1]))continue;
    const header=splitMD(lines[i]),separator=splitMD(lines[i+1]);
    if(separator.length!==header.length||!separator.every(cell=>/^:?-{3,}:?$/.test(cell)))continue;
    const rows=[header];i+=2;
    while(i<lines.length&&lines[i].includes('|')&&lines[i].trim()){rows.push(splitMD(lines[i]));i++;}
    tables.push(rows);
  }
  if(tables.length>1)throw new Error('Markdown 表が複数ある。取り込むタスク表だけを別ファイルに保存し、リスク表や会議表の誤読を防ぐ。');
  return tables[0]||[];
}
export function draftFrom(text,{extension,name=null,asOf=null,sourceName='plan.md',sourceSHA256=null}={}){
  if(asOf)validDate(asOf,'--as-of');
  const rows=extension==='.csv'?parseCSV(text):parseMarkdown(text),records=[];
  if(rows.length){
    const headers=rows[0];if(headers.some(value=>!value.trim())||new Set(headers).size!==headers.length)throw new Error('取り込む表の列名は空欄や重複にできない。');
    if(rows.length>301)throw new Error('一度に取り込める上限は 300 作業パッケージだ。プロジェクトの範囲に沿って分割する。');
    for(const [index,cells]of rows.slice(1).entries()){
      if(cells.length!==headers.length)throw new Error('取込み行 '+(index+2)+' の列数が列名の数と一致しない。');
      records.push({sourceRow:index+2,fields:Object.fromEntries(headers.map((key,i)=>[key,cells[i]]))});
    }
  }
  return {schema:'taskobo.pm-draft/v1',name,statusDate:asOf,baselineApproved:false,
    source:{file:sourceName,sha256:sourceSHA256,text},records,
    questions:['プロジェクト名、集計基準日、作業パッケージの識別子を確認する。','受入条件、グループ、A／Rを項目ごとに確認する。通常の担当者欄を最終責任者や実行担当者と自動的に同一視しない。','承認済み基準と現在の予測を区別する。資料の予定日を承認済み基準とは扱っていない。','タスクの状態、実績完了日、先行依存関係を確認する。'],
    note:records.length?'表の原値を保持した。承認済みプロジェクトはまだ作成していない。':'単一のタスク表が見つからなかった。原文を保持した。AIで事実を抽出し、不足情報を列挙する。'};
}
export async function initialize({from,out,name,'as-of':asOf}){
  if(!out)throw new Error('init 不足： --out 出力先ディレクトリ。');
  let bytes=Buffer.alloc(0),extension='.md';
  if(from){extension=path.extname(from).toLowerCase();if(!['.md','.markdown','.csv'].includes(extension))throw new Error('init 対応形式： UTF-8 Markdown または CSV；Excel 次の形式で保存する： CSV UTF-8，Word 先に次の形式で抽出する： Markdown テキスト。');bytes=await readFile(from);}
  const text=new TextDecoder('utf-8',{fatal:true}).decode(bytes);
  const draft=draftFrom(text,{extension,name,asOf,sourceName:from?path.basename(from):'資料未指定',sourceSHA256:from?createHash('sha256').update(bytes).digest('hex'):null});
  await mkdir(path.dirname(path.resolve(out)),{recursive:true});
  try{await mkdir(out);}catch(error){if(error.code==='EEXIST')throw new Error('初期化先が既に存在する。上書きできない：'+out);throw error;}
  await writeFile(path.join(out,'draft.json'),JSON.stringify(draft,null,2)+'\n',{flag:'wx'});
  await writeFile(path.join(out,'questions.md'),'# 初期化草稿・未確認\n\n'+draft.questions.map(question=>'- '+question).join('\n')+'\n\nAIでdraft.jsonからproject.jsonを整理する。不足情報はPMにまとめて確認する。完了後にpm.mjs checkを実行し、その後に描画する。\n',{flag:'wx'});
  await writeFile(path.join(out,'plan-template.csv'),'id,title,group,acceptance,accountable,responsible,baselineStart,baselineFinish,forecastStart,forecastFinish,status,actualFinish,dependsOn\n',{flag:'wx'});
  return {output:path.resolve(out),draft:path.join(path.resolve(out),'draft.json'),records:draft.records.length,status:'draft',message:'原文と表を保持した。未確認の日付、責任、基準は自動補完していない。'};
}
