import {readFile,writeFile,mkdir,mkdtemp,rename,rm,readdir,lstat,realpath} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import path from 'node:path';
export const sha=bytes=>createHash('sha256').update(bytes).digest('hex');

async function inventory(root,prefix=''){
  const files=[];
  for(const entry of await readdir(path.join(root,prefix),{withFileTypes:true})){
    const name=prefix+entry.name,info=await lstat(path.join(root,name));
    if(info.isSymbolicLink())throw new Error('出力先にシンボリックリンクがあるため更新できない：'+name);
    if(info.isDirectory()){const children=await inventory(root,name+'/');if(!children.length)throw new Error('出力先に生成記録のない空ディレクトリがある：'+name);files.push(...children);}
    else if(info.isFile())files.push(name);
    else throw new Error('出力先に対応外のファイルがある：'+name);
  }
  return files.sort();
}
export async function verifyOutput(directory,{strict=false}={}){
  const root=path.resolve(directory);
  if((await lstat(root)).isSymbolicLink())throw new Error('出力先をシンボリックリンクにはできない。');
  const report=JSON.parse(await readFile(path.join(root,'report.json'),'utf8'));
  if(report.schema!=='kobo.pm-render-report/v1'||!Object.keys(report.fileSHA256||{}).length)throw new Error('出力先に有効な生成報告がない。');
  const actual=await inventory(root);
  for(const [name,expected]of Object.entries(report.fileSHA256)){
    const file=path.resolve(root,name);
    if(name==='report.json'||!file.startsWith(root+path.sep)||!/^[a-f0-9]{64}$/.test(expected)||sha(await readFile(file))!==expected)throw new Error('出力検証に失敗：'+name+'；手作業の変更を保存し、新しい出力先を指定する。');
  }
  if(strict&&JSON.stringify(actual)!==JSON.stringify([...Object.keys(report.fileSHA256),'report.json'].sort()))throw new Error('生成報告にないファイルがあるため更新できない。ファイルを保存するか、新しい出力先を指定する。');
  return {directory:root,checkedFiles:Object.keys(report.fileSHA256).length,mode:report.mode,status:report.status||'complete',reportSHA256:sha(await readFile(path.join(root,'report.json')))};
}
export async function beginOutput(directory,{force=false,inputs=[]}={}){
  const out=path.resolve(directory);
  const canonical=value=>process.platform==='win32'?value.toLowerCase():value;
  const realOut=await realpath(out).catch(error=>{if(error.code!=='ENOENT')throw error;return out;});
  for(const value of inputs.filter(Boolean)){
    const input=canonical(await realpath(path.resolve(value)).catch(error=>{if(error.code!=='ENOENT')throw error;return path.resolve(value);})),target=canonical(realOut);
    if(input===target||input.startsWith(target+path.sep))throw new Error('出力先にプロジェクトやレビューの入力ファイルを含めることはできない。');
  }
  let previous=null,exists=false;
  try{await lstat(out);exists=true;}catch(error){if(error.code!=='ENOENT')throw error;}
  if(exists){if(!force)throw new Error('出力先が既に存在する。次のオプションを使用する： --force 本ツールが生成し変更されていないディレクトリを更新するか、新しい出力先を指定する。');previous=await verifyOutput(out,{strict:true});}
  await mkdir(path.dirname(out),{recursive:true});
  const stage=await mkdtemp(path.join(path.dirname(out),'.taskobo-render-'));
  const fileSHA256={};let retainStage=false;
  return {out,stage,
    async write(name,bytes){const file=path.resolve(stage,name);if(!file.startsWith(stage+path.sep))throw new Error('出力ファイルのパスが許可範囲外だ。');await mkdir(path.dirname(file),{recursive:true});await writeFile(file,bytes,{flag:'wx'});fileSHA256[name]=sha(bytes);},
    async commit(report){
      await writeFile(path.join(stage,'report.json'),JSON.stringify({...report,fileSHA256},null,2)+'\n',{flag:'wx'});
      retainStage=true;
      if(previous&&report.status!=='complete'){
        const failed=out+'.failed-'+path.basename(stage).slice('.taskobo-render-'.length);await rename(stage,failed);return failed;
      }
      if(previous){
        const checked=await verifyOutput(out,{strict:true});if(checked.reportSHA256!==previous.reportSHA256)throw new Error('描画中に出力先が変更されたため置換しなかった。新しい結果の保存先： '+stage);
        const backup=stage+'-previous';await rename(out,backup);
        try{await rename(stage,out);}catch(error){await rename(backup,out);throw error;}
        // backup is this call's validated, generated-only directory beside stage.
        await rm(backup,{recursive:true,force:true,maxRetries:5,retryDelay:200});
      }else{
        let occupied=false;try{await lstat(out);occupied=true;}catch(error){if(error.code!=='ENOENT')throw error;}
        if(occupied)throw new Error('描画中に出力先が作成されたため上書きしなかった。');
        await rename(stage,out);
      }
      return out;
    },
    async abort(){if(!retainStage&&stage.startsWith(path.dirname(out)+path.sep+'.taskobo-render-'))await rm(stage,{recursive:true,force:true});}
  };
}
