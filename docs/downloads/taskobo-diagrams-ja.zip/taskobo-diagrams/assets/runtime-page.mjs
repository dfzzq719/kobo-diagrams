// Presentation-only correction: completion points do not imply a known actual start.
function localizeSchedule(svg,date){
  const labels=[...svg.querySelectorAll('.taskobo-gantt-status-legend text')];
  if(![3,4].includes(labels.length))throw new Error('工程表の凡例に互換性がない。');
  const lines=[
    '基準＝白抜き破線　完了実績＝完了日の菱形（実績開始日不明）　予測＝塗り破線の期間',
    '危険色＝完了遅延・期限超過　注意色＝将来の遅延見込み　強調色＝期限内予測　成功色＝期限内完了',
    `差＝実績・予測終了日 − 基準終了日（暦日）　集計基準日 ${date}`,
    '計画案＝淡色の点線　白抜き菱形＝未承認の判断予定・計画節目'
  ];
  labels.forEach((label,index)=>{
    const walker=document.createTreeWalker(label,NodeFilter.SHOW_TEXT),nodes=[];
    while(walker.nextNode())nodes.push(walker.currentNode);
    if(!nodes.length)throw new Error('工程表の凡例に文字ノードがない。');
    nodes[0].data=lines[index];for(const node of nodes.slice(1))node.data='';
  });
}

import {createDiagramProfile,renderDocument,svgToPng,pngDimensions,CORE_VERSION,MERMAID_VERSION} from './runtime/core/index.mjs';

function rolePanel(svg,panel){
  const ns='http://www.w3.org/2000/svg',height=Number(svg.getAttribute('height')),width=1618;
  const title=svg.querySelector('.doc-title');if(title)title.textContent='責任分担｜役割 '+(panel.from+1)+'–'+(panel.from+panel.count);
  const legend=svg.querySelector('.raci-legend')?.cloneNode(true);
  const root=document.createElementNS(ns,'svg');
  for(const [key,value]of Object.entries({xmlns:ns,width,height,viewBox:`0 0 ${width} ${height}`,role:'img','aria-label':title?.textContent||'責任分担'}))root.setAttribute(key,value);
  const style=svg.querySelector('style');if(style)root.append(style.cloneNode(true));
  const background=document.createElementNS(ns,'rect');background.setAttribute('width','100%');background.setAttribute('height','100%');background.setAttribute('fill','#FFFEFA');root.append(background);
  for(const [x,viewX,w]of [[0,0,354],[354,354+panel.from*155,panel.count*155+24]]){
    const copy=svg.cloneNode(true);copy.querySelector('.raci-legend')?.remove();copy.querySelector('.doc-title')?.remove();
    copy.setAttribute('x',x);copy.setAttribute('width',w);copy.setAttribute('viewBox',`${viewX} 0 ${w} ${height}`);copy.setAttribute('overflow','hidden');root.append(copy);
  }
  if(title)root.append(title.cloneNode(true));if(legend)root.append(legend);
  return {svg:root,width,height};
}
const profile=createDiagramProfile({settings:{fontSize:22,density:'compact',curve:'linear'},standard:{name:'Taskobo Diagrams 日本語プロジェクト資料',version:'1'}});
window.__taskoboRender=async job=>{
  let stage='SVG 描画',holder;
  const progress=()=>console.info('TASKOBO_STAGE '+JSON.stringify({id:job.id,stage}));
  try{
    progress();
    let packet=await renderDocument(job.source,profile.roles,profile.settings,{mermaid:window.mermaid});
    holder=document.createElement('div');holder.style.cssText='position:absolute;left:0;top:0;visibility:hidden';holder.innerHTML=packet.svg;document.body.append(holder);
    await document.fonts.ready;
    let svg=holder.querySelector('svg');
    if(!svg||!Number.isFinite(packet.width)||packet.width<=0||!Number.isFinite(packet.height)||packet.height<=0)throw new Error('図表の有効な寸法を取得できない。');
    progress();
    if(job.kind==='schedule')localizeSchedule(svg,job.statusDate);
    if(job.rolePanel){const panel=rolePanel(svg,job.rolePanel);svg=panel.svg;packet={...packet,width:panel.width,height:panel.height};}
    const localized={...packet,svg:svg.outerHTML};
    const result={ok:true,svg:localized.svg,width:packet.width,height:packet.height,type:packet.type,notes:packet.notes||[]};
    if(job.format==='all'){
      stage='PNG 書出し';progress();
      try{
        const png=await svgToPng(localized,1);
        result.pngBase64=await new Promise((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>resolve(String(reader.result).split(',')[1]);reader.onerror=()=>reject(new Error('読み込めない： PNG。'));reader.readAsDataURL(png);});
        result.pngSize=pngDimensions(localized,1);
      }catch(error){result.warning={code:'PNG_EXPORT_FAILED',stage,message:'PNG 書出しに失敗した。有効な形式を保持した： SVG；使用できる形式： --format svg 再試行する。',detail:error.message};}
    }
    return result;
  }catch(error){return {ok:false,error:{code:error.code||'DIAGRAM_RENDER_FAILED',stage,message:error.message,detail:error.stack}};}
  finally{holder?.remove();}
};
window.__koboFinish({ok:true,profile,coreVersion:CORE_VERSION,mermaidVersion:MERMAID_VERSION});
